from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def quizpage():
    return render_template('index.html')
# @app.route('/done')
# def quizscore():
#     return render_template('done.html')


app.run(debug=True,host="192.168.43.116")
# quizpage()
